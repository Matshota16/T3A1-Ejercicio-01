package t3a1;

import java.util.Scanner;

public class Calificaciones {
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String grupo;
    private String carrera;
    private String nombreAsignatura1;
    private String nombreAsignatura2;
    private int calificacionAsignatura1;
    private int calificacionAsignatura2;
    private double promedio;

    public Calificaciones() {}      // Método constructor vacío

    public Calificaciones(String nombre, String apellidoPaterno, String apellidoMaterno, String grupo, String carrera, String nombreAsignatura1, String nombreAsignatura2, int calificacionAsignatura1,int calificacionAsignatura2, double promedio) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.grupo = grupo;
        this.carrera = carrera;
        this.nombreAsignatura1 = nombreAsignatura1;
        this.nombreAsignatura2 = nombreAsignatura2;
        this.calificacionAsignatura1 = calificacionAsignatura1;
        this.calificacionAsignatura2 = calificacionAsignatura2;
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return "Calificaciones{" + "nombre= " + nombre + ", apellido Paterno= " + apellidoPaterno + ", apellido Materno= " + apellidoMaterno + ", grupo= " + grupo + ", carrera= " + carrera + ", Primera Asignatura= " + nombreAsignatura1 + ", Segunda Asignatura= " + nombreAsignatura2 + ", Calificacion de la Primera Asignatura= " + calificacionAsignatura1 + ", Calificacion de la Segunda Asignatura =" + calificacionAsignatura2 + "promedio general: " + promedio + '}';
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getNombreAsignatura1() {
        return nombreAsignatura1;
    }

    public void setNombreAsignatura1(String nombreAsignatura) {
        this.nombreAsignatura1 = nombreAsignatura;
    }
    
    public String getNombreAsignatura2() {
        return nombreAsignatura2;
    }

    public void setNombreAsignatura2(String nombreAsignatura) {
        this.nombreAsignatura2 = nombreAsignatura;
    }

    public int getcalificacionAsignatura1() {
        return calificacionAsignatura1;
    }

    public void setcalificacionAsignatura1(int calificacionAsignatura1) {
        this.calificacionAsignatura1 = calificacionAsignatura1;
    }

    public int getcalificacionAsignatura2() {
        return calificacionAsignatura2;
    }

    public void setcalificacionAsignatura2(int calificacionAsignatura2) {
        this.calificacionAsignatura2 = calificacionAsignatura2;
    }
    
    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    
}

